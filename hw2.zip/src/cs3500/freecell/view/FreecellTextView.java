package cs3500.freecell.view;

import cs3500.freecell.model.FreecellModelState;
import java.util.Objects;

/**
 * Represents a text view of a Freecell model.
 */
public class FreecellTextView implements FreecellView {

  private final FreecellModelState<?> model;

  /**
   * Generates a text view of the Freecell model.
   *
   * @param model the model object to display as text
   * @throws NullPointerException if the model is null
   */
  public FreecellTextView(FreecellModelState<?> model) {
    this.model = Objects.requireNonNull(model);
  }

  @Override
  public String toString() {
    return this.model.toString();
  }
}
