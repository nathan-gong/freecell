package cs3500.freecell.model.hw02;

import cs3500.freecell.model.FreecellModel;
import cs3500.freecell.model.PileType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Represents the simple implementation of the Freecell game using Card objects.
 */
public class SimpleFreecellModel implements FreecellModel<ICard> {

  private final List<IPile<ICard>> foundation;
  private final List<IPile<ICard>> cascade;
  private final List<IPile<ICard>> open;
  private boolean gameState;

  /**
   * Constructs a simple Freecell model with empty lists of piles.
   */
  public SimpleFreecellModel() {
    this.foundation = new ArrayList<>();
    this.cascade = new ArrayList<>();
    this.open = new ArrayList<>();
    this.gameState = false;
  }

  @Override
  public List<ICard> getDeck() {
    List<ICard> deck = new ArrayList<>();
    for (Suit suit : Suit.values()) {
      for (Value value : Value.values()) {
        deck.add(new Card(value, suit));
      }
    }
    return deck;
  }

  @Override
  public void startGame(List<ICard> deck, int numCascadePiles, int numOpenPiles, boolean shuffle)
      throws IllegalArgumentException {
    if (!(this.isValidDeck(deck))) {
      throw new IllegalArgumentException("Provided deck is invalid");
    }
    // allow as few as four cascade piles and one open pile
    if (numCascadePiles < 4) {
      throw new IllegalArgumentException("Game must have at least four cascade piles");
    }
    if (numOpenPiles < 1) {
      throw new IllegalArgumentException("Game must have at least one open pile");
    }
    // make a deep copy of the deck to use for mutation
    List<ICard> deckCopy = new ArrayList<>();
    for (ICard card : deck) {
      deckCopy.add(new Card(card.getValue(), card.getSuit()));
    }
    // shuffle the deck if specified
    if (shuffle) {
      Collections.shuffle(deckCopy);
    }
    // initialize the piles and deal the deck
    this.dealCards(deckCopy, numCascadePiles, numOpenPiles);
    this.gameState = true;
  }

  /**
   * Checks if the given deck is valid.
   *
   * @param deck the deck to be checked for validity
   * @return whether the deck is valid
   */
  private boolean isValidDeck(List<ICard> deck) {
    // the deck is invalid if it is null
    if (deck == null) {
      return false;
    }
    // the deck is invalid if it does not have 52 cards
    if (deck.size() != 52) {
      return false;
    }
    // the deck is invalid if it contains duplicate or invalid cards
    return new HashSet<>(this.getDeck()).equals(new HashSet<>(deck));
  }

  /**
   * Deals the deck among the cascade piles in round robin fashion.
   *
   * @param deck the deck to be dealt
   * @param numCascadePiles the number of cascade piles
   * @param numOpenPiles the number of open piles
   */
  private void dealCards(List<ICard> deck, int numCascadePiles, int numOpenPiles) {
    this.initPiles(numCascadePiles, numOpenPiles);

    for (int i = 0; i < deck.size(); i++) {
      this.cascade.get(i % numCascadePiles).getPile().add(deck.get(i));
    }
  }

  /**
   * Initializes the card piles.
   *
   * @param numCascadePiles the number of cascade piles
   * @param numOpenPiles the number of open piles
   */
  private void initPiles(int numCascadePiles, int numOpenPiles) {
    // ensure lists of piles are empty
    if (this.gameState) {
      this.foundation.clear();
      this.cascade.clear();
      this.open.clear();
    }

    // add piles to corresponding lists
    int numFoundationPiles = Suit.values().length;
    for (int i = 0; i < numFoundationPiles; i++) {
      this.foundation.add(new FoundationPile(i + 1));
    }
    for (int i = 0; i < numCascadePiles; i++) {
      this.cascade.add(new CascadePile(i + 1));
    }
    for (int i = 0; i < numOpenPiles; i++) {
      this.open.add(new OpenPile(i + 1));
    }
  }

  @Override
  public void move(PileType source, int pileNumber, int cardIndex, PileType destination,
      int destPileNumber) throws IllegalArgumentException, IllegalStateException {
    this.hasGameStarted();
    Map<PileType, List<IPile<ICard>>> pileLists = this.getPileLists();

    // check source and destination PileTypes for validity
    if (!((source != PileType.FOUNDATION)
        && pileLists.containsKey(source)
        && pileLists.containsKey(destination))) {
      throw new IllegalArgumentException("Invalid source or destination pile type provided");
    }

    // move the card from the source pile to the destination card
    this.addToDestination(pileLists.get(destination), destPileNumber,
        this.removeFromSource(pileLists.get(source), pileNumber, cardIndex));
  }

  /**
   * Associates PileTypes with their corresponding lists of piles.
   *
   * @return a hashmap relating PileTypes to lists of piles
   */
  private Map<PileType, List<IPile<ICard>>> getPileLists() {
    Map<PileType, List<IPile<ICard>>> pileLists = new HashMap<>();
    pileLists.put(PileType.FOUNDATION, this.foundation);
    pileLists.put(PileType.CASCADE, this.cascade);
    pileLists.put(PileType.OPEN, this.open);
    return pileLists;
  }

  /**
   * Removes the specified card index from the source pile.
   *
   * @param sourcePileList the pile list to remove the card from
   * @param pileNumber the pile number of the given type, starting at 0
   * @param cardIndex the index of the card to be moved from the source pile, starting at 0
   * @return the card that was removed
   * @throws IllegalArgumentException if the pileNumber or the cardIndex are invalid
   * @throws IllegalStateException if a card cannot be removed
   */
  private ICard removeFromSource(List<IPile<ICard>> sourcePileList, int pileNumber, int cardIndex)
      throws IllegalArgumentException, IllegalStateException {
    this.isValidPileIndex(sourcePileList, pileNumber);
    IPile<ICard> pile = sourcePileList.get(pileNumber);
    int lastCardIndex = pile.getPile().size() - 1;
    if (cardIndex != lastCardIndex) {
      throw new IllegalArgumentException("Only the last card in a pile may be moved");
    }
    ICard card = pile.getPile().get(lastCardIndex);
    pile.remove();
    return card;
  }

  /**
   * Adds the specified card to the destination pile.
   *
   * @param destinationPileList the pile list to add the card to
   * @param destPileNumber the pile number of the given type, starting at 0
   * @param card the card to be moved to the destination pile
   * @throws IllegalArgumentException if the destPileNumber is invalid or the card cannot be added
   */
  private void addToDestination(List<IPile<ICard>> destinationPileList, int destPileNumber,
      ICard card) throws IllegalArgumentException {
    this.isValidPileIndex(destinationPileList, destPileNumber);
    destinationPileList.get(destPileNumber).add(card);
  }

  @Override
  public boolean isGameOver() {
    // check that there are 4 foundation piles, each having 13 cards
    boolean gameOver = (this.foundation.size() == Suit.values().length)
        && this.foundation.stream().allMatch(pile -> pile.getPile().size() == 13);
    // update the game state if in an applicable situation
    if (gameOver || this.gameState) {
      this.gameState = !gameOver;
    }
    return gameOver;
  }

  /**
   * Checks if the pile number of the pile list exists.
   *
   * @param pileList the pile list to be checked
   * @param index the pile number of the pile list
   * @throws IllegalArgumentException if the index is out of the allowable range
   */
  private void isValidPileIndex(List<IPile<ICard>> pileList, int index)
      throws IllegalArgumentException {
    if (index >= pileList.size() || index < 0) {
      throw new IllegalArgumentException("Given pile number is out of range of the pile list");
    }
  }

  /**
   * Checks if the card index of the card pile exists.
   *
   * @param pile the pile to be checked
   * @param index the index of the card in the above foundation pile, starting at 0
   * @throws IllegalArgumentException if the index is out of the allowable range
   */
  private void isValidCardIndex(IPile<ICard> pile, int index) throws IllegalArgumentException {
    if (index >= pile.getPile().size() || index < 0) {
      throw new IllegalArgumentException("Given card index is out of range of the pile");
    }
  }

  /**
   * Checks if the game has started.
   *
   * @throws IllegalStateException if the game has not started
   */
  private void hasGameStarted() throws IllegalStateException {
    if (!this.gameState) {
      throw new IllegalStateException("The game has not started");
    }
  }

  @Override
  public int getNumCardsInFoundationPile(int index)
      throws IllegalArgumentException, IllegalStateException {
    this.hasGameStarted();
    this.isValidPileIndex(this.foundation, index);
    return this.foundation.get(index).getPile().size();
  }

  @Override
  public int getNumCascadePiles() {
    return this.gameState ? this.cascade.size() : -1;
  }

  @Override
  public int getNumCardsInCascadePile(int index)
      throws IllegalArgumentException, IllegalStateException {
    this.hasGameStarted();
    this.isValidPileIndex(this.cascade, index);
    return this.cascade.get(index).getPile().size();
  }

  @Override
  public int getNumCardsInOpenPile(int index)
      throws IllegalArgumentException, IllegalStateException {
    this.hasGameStarted();
    this.isValidPileIndex(this.open, index);
    return this.open.get(index).getPile().size();
  }

  @Override
  public int getNumOpenPiles() {
    return this.gameState ? this.open.size() : -1;
  }

  @Override
  public ICard getFoundationCardAt(int pileIndex, int cardIndex)
      throws IllegalArgumentException, IllegalStateException {
    this.hasGameStarted();
    this.isValidPileIndex(this.foundation, pileIndex);
    IPile<ICard> pile = this.foundation.get(pileIndex);
    this.isValidCardIndex(pile, cardIndex);
    return pile.getPile().get(cardIndex);
  }

  @Override
  public ICard getCascadeCardAt(int pileIndex, int cardIndex)
      throws IllegalArgumentException, IllegalStateException {
    this.hasGameStarted();
    this.isValidPileIndex(this.cascade, pileIndex);
    IPile<ICard> pile = this.cascade.get(pileIndex);
    this.isValidCardIndex(pile, cardIndex);
    return pile.getPile().get(cardIndex);
  }

  @Override
  public ICard getOpenCardAt(int pileIndex) throws IllegalArgumentException, IllegalStateException {
    this.hasGameStarted();
    this.isValidPileIndex(this.open, pileIndex);
    IPile<ICard> pile = this.open.get(pileIndex);
    if (pile.getPile().size() > 0) {
      return pile.getPile().get(0);
    }
    return null;
  }

  @Override
  public String toString() {
    List<IPile<ICard>> pileList = new ArrayList<>(this.foundation);
    pileList.addAll(this.open);
    pileList.addAll(this.cascade);

    Iterator<IPile<ICard>> iter = pileList.iterator();
    StringBuilder board = new StringBuilder();

    if (iter.hasNext()) {
      IPile<ICard> pile = iter.next();
      board.append(pile.toString());
    }
    else {
      return "";
    }

    while (iter.hasNext()) {
      IPile<ICard> pile = iter.next();
      board.append("\n");
      board.append(pile.toString());
    }
    return board.toString();
  }
}
