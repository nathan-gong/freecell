import static org.junit.Assert.assertEquals;

import cs3500.freecell.model.FreecellModel;
import cs3500.freecell.model.PileType;
import cs3500.freecell.model.hw02.ICard;
import cs3500.freecell.model.hw02.SimpleFreecellModel;
import cs3500.freecell.view.FreecellTextView;
import cs3500.freecell.view.FreecellView;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

/**
 * Test class for the FreecellTextView class.
 */
public class FreecellTextViewTest {

  FreecellView fv1;
  FreecellModel<ICard> m1;
  List<ICard> l1;

  /**
   * Initialize variables for testing.
   */
  @Before
  public void init() {
    this.m1 = new SimpleFreecellModel();
    this.l1 = this.m1.getDeck();
    this.fv1 = new FreecellTextView(this.m1);
  }

  // view is illegal if the model is null
  @Test(expected = NullPointerException.class)
  public void testIllegalConstructor() {
    new FreecellTextView(null);
  }

  // test String representation of the view before the game has started
  @Test
  public void testToStringBeforeStart() {
    assertEquals("", this.fv1.toString());
  }

  // test String representation of the view after the game has started
  @Test
  public void testToStringAfterStart() {
    this.m1.startGame(this.l1, 8, 4, false);
    this.m1.move(PileType.CASCADE, 7, 5, PileType.OPEN, 0);
    this.m1.move(PileType.CASCADE, 7, 4, PileType.FOUNDATION, 1);
    String s = "F1:\n"
        + "F2: A♠\n"
        + "F3:\n"
        + "F4:\n"
        + "O1: 9♠\n"
        + "O2:\n"
        + "O3:\n"
        + "O4:\n"
        + "C1: A♣, 9♣, 4♦, Q♦, 7♥, 2♠, 10♠\n"
        + "C2: 2♣, 10♣, 5♦, K♦, 8♥, 3♠, J♠\n"
        + "C3: 3♣, J♣, 6♦, A♥, 9♥, 4♠, Q♠\n"
        + "C4: 4♣, Q♣, 7♦, 2♥, 10♥, 5♠, K♠\n"
        + "C5: 5♣, K♣, 8♦, 3♥, J♥, 6♠\n"
        + "C6: 6♣, A♦, 9♦, 4♥, Q♥, 7♠\n"
        + "C7: 7♣, 2♦, 10♦, 5♥, K♥, 8♠\n"
        + "C8: 8♣, 3♦, J♦, 6♥";
    assertEquals(s, this.fv1.toString());
  }
}
