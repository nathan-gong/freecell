package cs3500.freecell;

import cs3500.freecell.controller.FreecellController;
import cs3500.freecell.controller.SimpleFreecellController;
import cs3500.freecell.model.hw02.ICard;
import cs3500.freecell.model.hw02.SimpleFreecellModel;
import java.io.InputStreamReader;

/**
 * Main class used to play a Freecell game.
 */
public class Main {

  /**
   * Main method used to start playing the game with a controller.
   *
   * @param args the command line arguments passed to the main method
   */
  public static void main(String[] args) {
    FreecellController<ICard> c = new SimpleFreecellController(new SimpleFreecellModel(),
        new InputStreamReader(System.in), System.out);
    c.playGame(new SimpleFreecellModel().getDeck(), 8, 4, true);
  }
}
